Stylized realistic package SVG icons

Included packages:
- DIP (generic), DIP-8, DIP-12, DIP-14, DIP-16, DIP-18, DIP-20, DIP-24, DIP-28, DIP-40
- SO-14
- TO-1, TO-3, TO-18, TO-39, TO-66, TO-72, TO-92, TO-126, TO-220, TO-218, TO-247

Design rules:
- Transparent background
- No fixed width/height, only viewBox
- currentColor used for strokes and subtle body fill
- Rounded line caps and joins
- Intended as clean master SVGs for labels, inventory and UI
